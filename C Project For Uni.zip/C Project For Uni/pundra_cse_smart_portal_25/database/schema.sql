CREATE TABLE activity_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT, action TEXT, details TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE attendance(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT, course_code TEXT, student_id TEXT, status TEXT, note TEXT, updated_by TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(date, course_code, student_id));

CREATE TABLE blood_donors(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT, full_name TEXT, blood_group TEXT, phone TEXT, last_donation TEXT, availability TEXT, note TEXT);

CREATE TABLE canteen_items(id INTEGER PRIMARY KEY AUTOINCREMENT, item_name TEXT UNIQUE, price REAL, category TEXT, status TEXT DEFAULT 'Available');

CREATE TABLE canteen_orders(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT, item_name TEXT, quantity INTEGER, unit_price REAL, total REAL, order_date TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE courses(id INTEGER PRIMARY KEY AUTOINCREMENT, course_code TEXT UNIQUE, course_title TEXT, credit REAL, course_type TEXT, department TEXT, batch TEXT, semester TEXT, teacher_short TEXT, teacher_name TEXT, room TEXT, status TEXT DEFAULT 'Active');

CREATE TABLE ct_exams(id INTEGER PRIMARY KEY AUTOINCREMENT, course_code TEXT, title TEXT, exam_type TEXT, exam_date TEXT, full_mark REAL, note TEXT, status TEXT DEFAULT 'Scheduled');

CREATE TABLE departments(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE, summary TEXT, vision TEXT, mission TEXT, source_url TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE group_members(id INTEGER PRIMARY KEY AUTOINCREMENT, group_id INTEGER, student_id TEXT, student_name TEXT, reason TEXT, status TEXT DEFAULT 'Pending', created_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE groups_table(id INTEGER PRIMARY KEY AUTOINCREMENT, group_name TEXT UNIQUE, focus_area TEXT, description TEXT, leader TEXT, meeting_time TEXT, status TEXT DEFAULT 'Open');

CREATE TABLE labs(id INTEGER PRIMARY KEY AUTOINCREMENT, lab_name TEXT UNIQUE, room_no TEXT, pc_count INTEGER, available_pc INTEGER, lab_assistant TEXT, status TEXT, details TEXT);

CREATE TABLE library_books(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT UNIQUE, author TEXT, category TEXT, total_copy INTEGER, available_copy INTEGER, shelf TEXT);

CREATE TABLE library_issues(id INTEGER PRIMARY KEY AUTOINCREMENT, book_id INTEGER, student_id TEXT, student_name TEXT, issue_date TEXT, due_date TEXT, return_date TEXT, status TEXT DEFAULT 'Issued');

CREATE TABLE mail_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, recipient TEXT, subject TEXT, message TEXT, status TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE notices(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT, course_code TEXT, notice_from TEXT, message TEXT, priority TEXT, publish_date TEXT, status TEXT DEFAULT 'Active');

CREATE TABLE settings(id INTEGER PRIMARY KEY AUTOINCREMENT, key TEXT UNIQUE, value TEXT);

CREATE TABLE student_reports(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT, student_name TEXT, report_type TEXT, details TEXT, status TEXT DEFAULT 'Open', created_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT, roll_no TEXT, student_id TEXT UNIQUE, full_name TEXT, department TEXT, batch TEXT, semester TEXT, phone TEXT, email TEXT, address TEXT, status TEXT DEFAULT 'Active');

CREATE TABLE teachers(id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT UNIQUE, short_form TEXT, designation TEXT, mobile TEXT, email TEXT, department TEXT, photo_url TEXT, status TEXT DEFAULT 'Active');

CREATE TABLE users(id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT, email TEXT UNIQUE, password_hash TEXT, role TEXT, department TEXT, batch TEXT, semester TEXT, status TEXT DEFAULT 'Active', created_at TEXT DEFAULT CURRENT_TIMESTAMP);


CREATE TABLE department_images(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT UNIQUE, description TEXT, image_url TEXT, source_url TEXT);

CREATE TABLE routine_assets(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT UNIQUE, image_url TEXT, note TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);

CREATE TABLE routine_slots(id INTEGER PRIMARY KEY AUTOINCREMENT, day_name TEXT, time_slot TEXT, course_code TEXT, teacher_short TEXT, room_no TEXT, note TEXT, UNIQUE(day_name,time_slot,course_code));

CREATE TABLE result_records(id INTEGER PRIMARY KEY AUTOINCREMENT, student_id TEXT, student_name TEXT, course_code TEXT, course_title TEXT, credit REAL, marks REAL, letter_grade TEXT, grade_point REAL, published_by TEXT, publish_date TEXT DEFAULT CURRENT_TIMESTAMP, UNIQUE(student_id, course_code));
