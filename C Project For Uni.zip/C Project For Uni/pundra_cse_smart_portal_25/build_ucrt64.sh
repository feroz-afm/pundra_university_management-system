#!/usr/bin/env bash
gcc src/main.c -o PundraCSESmartPortal25.exe -lsqlite3 -lws2_32
