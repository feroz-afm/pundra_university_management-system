@echo off
REM Run this inside MSYS2 UCRT64 shell or use build_ucrt64.sh.
echo Open MSYS2 UCRT64 and run: gcc src/main.c -o PundraCSESmartPortal25.exe -lsqlite3 -lws2_32
echo Then run: PundraCSESmartPortal25.exe
pause
